﻿using Newtonsoft.Json;
using PizzaDeliveryBot.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;

namespace PizzaDeliveryBot.Services
{
    public class JsonService
    {
        /// <summary>
        /// Fetch data from JSON File
        /// </summary>
        /// <returns></returns>
        public static StoreDataModel FetchDataFromJson()
        {
            var path = HttpContext.Current.Server.MapPath("~/Data/PizzaData.json");
            return JsonConvert.DeserializeObject<StoreDataModel>(File.ReadAllText(path));
        }
    }
}