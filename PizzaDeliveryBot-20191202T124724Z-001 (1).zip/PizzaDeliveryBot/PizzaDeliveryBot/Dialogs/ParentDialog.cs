﻿using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.FormFlow;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
using Microsoft.Bot.Connector;
using PizzaDeliveryBot.Constants;
using PizzaDeliveryBot.Models;
using PizzaDeliveryBot.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace PizzaDeliveryBot.Dialogs
{
    //[LuisModel("1184da3a-8fc1-4168-b7e7-10826e9d4b09", "2342b419697348378328678f56a192af", domain: "westus.api.cognitive.microsoft.com")]
    [LuisModel("1bf92b17-b522-4b71-a80f-76aa2bee9492", "b04864b953cc46d3ad97376c90a1376a", domain: "westus.api.cognitive.microsoft.com")]
    [Serializable]
    public class ParentDialog : LuisDialog<PizzaOrder>
    {
        
        PizzaOrder Order = new PizzaOrder();

        public StoreDataModel DB {
            get {
                return JsonService.FetchDataFromJson();
            }
        }

        [LuisIntent("")]
        public async Task None(IDialogContext context, LuisResult result)
        {
            await context.PostAsync("I'm sorry. I didn't understand you.");
            context.Wait(MessageReceived);
        }

        [LuisIntent("Greeting")]
        public async Task Greeting(IDialogContext context, LuisResult result)
        {
            await context.PostAsync("Hello, Welcome to Miracle Pizza. I am Edward, your steward for the day. How may I help you today?");
            
            context.Wait(MessageReceived);
        }

        [LuisIntent("DisplayCart")]
        public async Task DisplayCart(IDialogContext context, LuisResult result)
        {
            var reply = context.MakeMessage();
            reply.Attachments.Add(Order.ToReceiptCard());
            
            await context.PostAsync(reply);
        }

        [LuisIntent("Reset")]
        public async Task Reset(IDialogContext context, LuisResult result)
        {
            RESET();

            await ShowOptions(context);
        }

        [LuisIntent("Checkout")]
        public async Task Checkout(IDialogContext context, LuisResult result)
        {
            if(Order.OrderItems.Count <= 0)
            {
                await context.PostAsync("There are no items in your cart. Try saying, 'I want to add an item' first.");
                return;
            }

            var OrderTypeForm = new FormDialog<TypeOfOrder>(new TypeOfOrder(), TypeOfOrder.BuildForm, FormOptions.PromptInStart);
            context.Call<TypeOfOrder>(OrderTypeForm, AfterOrderTypeEntered);
        }

        private async Task AfterOrderTypeEntered(IDialogContext context, IAwaitable<TypeOfOrder> result)
        {
            var OrderType = await result;

            Order.OrderType = OrderType.Type;

            if(Order.OrderType == Models.OrderType.Delivery)
            {
                PromptDialog.Text(context, AskDeliveryAddress, "Please enter your address.");
            }
            else
            {
                var reply = context.MakeMessage();
                reply.Attachments.Add(Order.ToReceiptCard());
                reply.Text = $"Your order has been confirmed. You can pickup your order 45 mins from now. \n\nThank you.";
                await context.PostAsync(reply);

                OrderCompleted();
                context.Wait(MessageReceived);
            }
        }

        private async Task AskDeliveryAddress(IDialogContext context, IAwaitable<string> result)
        {
            var address = await result;
            Order.Address = address;

            var reply = context.MakeMessage();
            reply.Attachments.Add(Order.ToReceiptCard());
            reply.Text = $"Your order has been confirmed. Your order will be delivered in 50 minutes to \n\n \n\n{Order.Address}. \n\n \n\nThank you.";
            await context.PostAsync(reply);

            OrderCompleted();
            context.Wait(MessageReceived);
        }

        private void OrderCompleted()
        {
            Order = new PizzaOrder { User = Order.User };
        }

        private void RESET() {
            Order = new PizzaOrder();
        }

        [LuisIntent("AddItem")]
        public async Task AddItemToOrder(IDialogContext context, LuisResult result)
        {
            //IF USER DETAILS UNKNOWN
            if(Order.User == null)
            {
                await context.PostAsync($"Before we begin with your order, please provide the following details.");

                var UserDetailsForm = new FormDialog<UserInfo>(new UserInfo(), UserInfo.BuildForm, FormOptions.PromptInStart);

                context.Call<UserInfo>(UserDetailsForm, AfterUserDetailsEntered);

                return;
            }

            //await context.PostAsync($"Hello {Order.User.Name}");
            await ShowMenu(context, result);
            
        }
        
        private async Task AfterUserDetailsEntered(IDialogContext context, IAwaitable<UserInfo> result)
        {
            UserInfo user = null;
            try
            {
                user = await result;
                Order.User = user;

                await context.PostAsync($"Thank you. You are now all set to order at Miracle Pizza. You can start by responding with 'I want to place an order'");

                await ShowOptions(context);
            }
            catch (OperationCanceledException)
            {
                await context.PostAsync("You canceled the form!");
            }
            finally
            {
                context.Wait(this.MessageReceived);
            }
            
            
        }

        private async Task ShowOptions(IDialogContext context)
        {
            var reply = context.MakeMessage();
            reply.Text = $"Here's what you can order.";
            reply.AttachmentLayout = AttachmentLayoutTypes.List;
            reply.Attachments = Messages.OrderingOptions.ToAttachmentList();

            await context.PostAsync(reply);
        }

        private async Task ShowMoreOptions(IDialogContext context)
        {
            var reply = context.MakeMessage();
            reply.Text = $"What do you want to do next ?";
            reply.AttachmentLayout = AttachmentLayoutTypes.List;
            reply.Attachments = Messages.MoreOptions.ToAttachmentList();

            await context.PostAsync(reply);
        }


        private async Task ShowMenu(IDialogContext context, LuisResult result)
        {
            try
            {
                var res = result.Entities.Where(e => e.Type == "ItemCategory")?.FirstOrDefault()?.Entity;
                var category = ProcessItemCategory(res);

                List<Item>[] items = new List<Item>[4] { null, null, null, null};

                switch (category)
                {
                    case "pizza":
                        items[0] = DB.Items.Where(p => p.Category == "pizza" && p.IsVeg).ToList();
                        items[1] = DB.Items.Where(p => p.Category == "pizza" && !p.IsVeg).ToList();
                        break;
                    case "side":
                        items[0] = DB.Items.Where(p => p.Category == "side").ToList();
                        break;
                    case "drink":
                        items[0] = DB.Items.Where(p => p.Category == "drink").ToList();
                        break;
                    default:
                        items[0] = DB.Items.Where(p => p.Category == "pizza" && p.IsVeg).ToList();
                        items[1] = DB.Items.Where(p => p.Category == "pizza" && !p.IsVeg).ToList();
                        items[2] = DB.Items.Where(p => p.Category == "side").ToList();
                        items[3] = DB.Items.Where(p => p.Category == "drink").ToList();
                        break;
                }

                

                for (int i = 0; i < items.Length; i++)
                {
                    if (items[i] != null)
                    {
                        var reply = context.MakeMessage();
                        reply.AttachmentLayout = AttachmentLayoutTypes.Carousel;

                        reply.Attachments = items[i].ToAttachmentList();

                        await context.PostAsync(reply);
                    }
                }

                
                
            }
            catch (Exception E)
            {
                await context.PostAsync($"Something went wrong. Error: {E.Message}");
                
            }
            finally
            {
                context.Wait(MessageReceived);
            }
            
        }

        [LuisIntent("System.ChooseItem")]
        public async Task ChooseItem(IDialogContext context, LuisResult result)
        {
            try
            {
                int ItemId = Convert.ToInt32(result.Entities.Where(p => p.Type == "ItemId")?.FirstOrDefault().Entity);
                var SelectedItem = DB.Items.Find(p => p.Id == ItemId);

                if(SelectedItem.Category == "pizza")
                {
                    context.ConversationData.SetValue(ConversationConstants.SelectItem, SelectedItem);
                    var PizzaSizeForm = new FormDialog<ItemSizePizza>(new ItemSizePizza(), ItemSizePizza.BuildForm, FormOptions.PromptInStart);

                    context.Call<ItemSizePizza>(PizzaSizeForm, AfterPizzaSizeSelected);

                    return;
                }
                else if(SelectedItem.Category == "drink") // ASK SIZE SMALL or LARGE
                {
                    context.ConversationData.SetValue(ConversationConstants.SelectItem, SelectedItem);
                    var DrinkSizeForm = new FormDialog<ItemSizeDrink>(new ItemSizeDrink(), ItemSizeDrink.BuildForm, FormOptions.PromptInStart);

                    context.Call<ItemSizeDrink>(DrinkSizeForm, AfterDrinkSizeSelected);

                    return;
                }
                else // SideDish
                {

                    try
                    {
                        var orderItem = Order.OrderItems.Find(p => p.ItemName == SelectedItem.Name);
                        orderItem.Quantity++;
                    }
                    catch (Exception E)
                    {
                        Order.OrderItems.Add(new OrderItem
                            {
                                ItemName = SelectedItem.Name,
                                PricePerItem = SelectedItem.Cost.Small,
                                ItemDisplayPictureURL = SelectedItem.ThumbnailUrl,
                                Quantity = 1
                            }
                        );
                    }
                    await context.PostAsync($"A side dish, {SelectedItem.Name}, has been added to your cart.");
                    await ShowMoreOptions(context);
                }

                
            }
            catch (Exception)
            {
                await context.PostAsync($"Invalid Request");
            }
            
            
            context.Wait(MessageReceived);
        }

        private async Task AfterPizzaSizeSelected(IDialogContext context, IAwaitable<ItemSizePizza> result)
        {
            var pizzaSize = await result;
            var SelectedItem = context.ConversationData.GetValue<Item>(ConversationConstants.SelectItem);

            double cost;

            if (pizzaSize.Size == PizzaSize.Small)
                cost = SelectedItem.Cost.Small;
            else if (pizzaSize.Size == PizzaSize.Medium)
                cost = SelectedItem.Cost.Medium;
            else
                cost = SelectedItem.Cost.Large;

            Order.OrderItems.Add(new OrderItem
                {
                    ItemName = SelectedItem.Name,
                    PricePerItem = cost,
                    ItemDisplayPictureURL = SelectedItem.ThumbnailUrl,
                    Quantity = 1
                }
            );

            await context.PostAsync($"A {pizzaSize.Size} {SelectedItem.Name} pizza has been added to your cart.");
            await ShowMoreOptions(context);
        }

        private async Task AfterDrinkSizeSelected(IDialogContext context, IAwaitable<ItemSizeDrink> result)
        {
            var drinkSize = await result;

            var SelectedItem = context.ConversationData.GetValue<Item>(ConversationConstants.SelectItem);

            Order.OrderItems.Add(new OrderItem
                {
                    ItemName = SelectedItem.Name,
                    PricePerItem = drinkSize.Size == DrinkSize.Small ? SelectedItem.Cost.Small : SelectedItem.Cost.Large,
                    ItemDisplayPictureURL = SelectedItem.ThumbnailUrl,
                    Quantity = 1
                }
            );
            await context.PostAsync($"A {drinkSize.Size} {SelectedItem.Name} has been added to your cart.");

            await ShowMoreOptions(context);
        }

        private string ProcessItemCategory(string data)
        {
            if (String.IsNullOrEmpty(data))
            {
                return "";
            }

            if (data.ToLower().Contains("pizza"))
                return "pizza";
            else if (data.ToLower().Contains("side")) 
                return "side";
            else if (data.ToLower().Contains("drink"))
                return "drink";
            else
                return "";
        }
    }
}