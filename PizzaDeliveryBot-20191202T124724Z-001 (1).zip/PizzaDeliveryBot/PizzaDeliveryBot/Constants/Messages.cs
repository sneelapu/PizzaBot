﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PizzaDeliveryBot.Constants
{
    public class Messages
    {
        public static readonly string ConfirmUserInfo= "Name: \"{Name}\" and Phone number: \"{Phone}\". Is that correct? {||}";

        public static readonly List<KeyValuePair<string, string>> OrderingOptions = new List<KeyValuePair<string, string>> {
            new KeyValuePair<string, string>("Pizza", "I want to order a pizza"),
            new KeyValuePair<string, string>("Side Dish", "I want to order a side dish"),
            new KeyValuePair<string, string>("Full Menu", "Show me the entire menu")
        };

        public static readonly List<KeyValuePair<string, string>> MoreOptions = new List<KeyValuePair<string, string>> {
            new KeyValuePair<string, string>("Add more items to the cart.", "I want to add an item"),
            new KeyValuePair<string, string>("See my cart", "Show me my cart"),
            new KeyValuePair<string, string>("Checkout", "Checkout")
        };

    }
}