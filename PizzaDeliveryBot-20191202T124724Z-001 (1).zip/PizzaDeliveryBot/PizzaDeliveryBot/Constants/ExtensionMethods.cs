﻿using Microsoft.Bot.Connector;
using PizzaDeliveryBot.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PizzaDeliveryBot.Constants
{
    public static class ExtensionMethods
    {
        public static IList<Attachment> ToAttachmentList(this List<Item> items)
        {
            var attachements =  new List<Attachment>();

            foreach (var item in items)
            {
                string text = null;

                switch (item.Category)
                {
                    case "pizza":
                        text = $"Small: ${item.Cost.Small}\n\nMedium: ${item.Cost.Medium}\n\nLarge: ${item.Cost.Large}";
                        break;
                    case "side":
                        text = $"Small: ${item.Cost.Small}";
                        break;
                    case "drink":
                        text = $"Small: ${item.Cost.Small}\n\nLarge: ${item.Cost.Large}";
                        break;
                    default:
                        break;
                }

                if (!String.IsNullOrEmpty(text))
                {
                    var heroCard = new HeroCard
                    {
                        Title = item.Name,
                        Subtitle = item.Description,
                        Text = text,
                        Images = new List<CardImage>() { new CardImage(url: item.PosterUrl) },
                        Buttons = new List<CardAction>() { new CardAction(ActionTypes.PostBack, $"Add {item.Name}", value: $"System.ChooseItem({item.Id})") },
                    };
                    attachements.Add(heroCard.ToAttachment());
                }
            }

            return attachements;
        }

        public static IList<Attachment> ToAttachmentList(this List<KeyValuePair<string, string>> items)
        {
            var attachements = new List<Attachment>();
            var actions = new List<CardAction>();

            foreach (var item in items)
            {
                actions.Add(new CardAction(ActionTypes.ImBack, title: item.Key, value: item.Value));
            }

            var heroCard = new HeroCard
            {
                Title = "",
                Buttons = actions,
            };

            attachements.Add(heroCard.ToAttachment());

            return attachements;
        }
    }
}