﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PizzaDeliveryBot.Constants
{
    public class ConversationConstants
    {
        public static readonly string LUISResult = "LUISResult";

        public static readonly string SelectItem = "SelectItem";

    }
}