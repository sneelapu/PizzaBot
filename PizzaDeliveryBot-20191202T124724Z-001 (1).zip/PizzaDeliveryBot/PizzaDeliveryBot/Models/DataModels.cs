﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PizzaDeliveryBot.Models
{
    [Serializable]
    public class StoreDataModel
    {
        [JsonProperty("items")]
        public List<Item> Items { get; set; }
    }

    [Serializable]
    public class Item
    {
        [JsonProperty("id")]
        public int Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("category")]
        public string Category { get; set; }

        [JsonProperty("veg")]
        public bool IsVeg { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("cost")]
        public Cost Cost { get; set; }

        [JsonProperty("thumbUrl")]
        public string ThumbnailUrl { get; set; }

        [JsonProperty("posterUrl")]
        public string PosterUrl { get; set; }
    }

    [Serializable]
    public class Cost
    {
        [JsonProperty("small")]
        public double Small { get; set; }

        [JsonProperty("medium")]
        public double Medium { get; set; }

        [JsonProperty("large")]
        public double Large { get; set; }

    }
}