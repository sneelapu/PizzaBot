﻿using Microsoft.Bot.Builder.FormFlow;
using Microsoft.Bot.Connector;
using PizzaDeliveryBot.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PizzaDeliveryBot.Models
{
    [Serializable]
    public class PizzaOrder
    {
        public string OrderNumber { get; set; }

        public UserInfo User { get; set; }
        public OrderType OrderType { get; set; }

        public string Address { get; set; }

        public List<OrderItem> OrderItems { get; set; }

        public double GrandTotal { get { return OrderItems.Select(p => p.SubTotal).Sum(); } }

        public PizzaOrder()
        {
            OrderItems = new List<OrderItem>();
        }

        public List<ReceiptItem> ToReceiptItemList()
        {
            var list = new List<ReceiptItem>();
            foreach (var item in OrderItems)
            {
                list.Add(new ReceiptItem(item.ItemName, price: $"{item.SubTotal}", quantity: $"{item.Quantity}", image: new CardImage(url: item.ItemDisplayPictureURL), subtitle: $"$ {item.PricePerItem} x {item.Quantity}"));
            }
            return list;
        }

        public Attachment ToReceiptCard()
        {
            var receiptCard = new ReceiptCard
            {
                Title = User.Name,
                Facts = new List<Fact> { new Fact("Order Number", "6556-919"), new Fact("Phone number", User.Phone) },
                Items = ToReceiptItemList(),
                Tax = $"$ {5.0/100*GrandTotal}",
                Total = $"$ {105.0/100*GrandTotal}"
                //Buttons = new List<CardAction>
                //{
                //    new CardAction(
                //        ActionTypes.OpenUrl,
                //        "More information",
                //        "https://account.windowsazure.com/content/6.10.1.38-.8225.160809-1618/aux-pre/images/offer-icon-freetrial.png",
                //        "https://azure.microsoft.com/en-us/pricing/")
                //}
            };

            return receiptCard.ToAttachment();
        }
    }

    [Serializable]
    public class UserInfo
    {
        [Prompt("May I know your name please?")]
        public string Name { get; set; }

        [Prompt("Can you please enter your phone number?")]
        public string Phone { get; set; }

        public static IForm<UserInfo> BuildForm()
        {
            var builder = new FormBuilder<UserInfo>();
            
            return builder
                .Field("Name")
                .AddRemainingFields()
                .Confirm(Messages.ConfirmUserInfo)
                .Build();
        }

        public override string ToString()
        {
            return $"Name: {Name} \n\nPhone: {Phone}";
        }
    }

    [Serializable]
    public class OrderItem
    {
        public string ItemDisplayPictureURL { get; set; }

        public string ItemName { get; set; }

        public int Quantity { get; set; }

        public double PricePerItem { get; set; }


        public double SubTotal { get { return Quantity * PricePerItem; } }

        
    }


    [Serializable]
    public class ItemSizeDrink
    {
        [Prompt("Please select a size. (Small - 12 oz & Large 20 oz) {||}")]
        public DrinkSize Size;

        public static IForm<ItemSizeDrink> BuildForm()
        {
            var builder = new FormBuilder<ItemSizeDrink>();

            return builder
                .Field("Size")
                .Build();
        }
    }

    [Serializable]
    public class ItemSizePizza
    {
        [Prompt("Please select a size. (Small - 6 slices, Medium - 8 slices & Large 10 slices) {||}")]
        public PizzaSize Size;

        public static IForm<ItemSizePizza> BuildForm()
        {
            var builder = new FormBuilder<ItemSizePizza>();

            return builder
                .Field("Size")
                .Build();
        }
    }

    [Serializable]
    public class TypeOfOrder
    {
        [Prompt("Which one do you prefer ? {||}")]
        public OrderType Type;

        public static IForm<TypeOfOrder> BuildForm()
        {
            var builder = new FormBuilder<TypeOfOrder>();

            return builder
                .Field("Type")
                .Build();
        }
    }

    public enum PizzaSize { Small = 1, Medium, Large}
    public enum DrinkSize { Small = 1, Large }

    public enum OrderType { Delivery = 1, Pickup}
}