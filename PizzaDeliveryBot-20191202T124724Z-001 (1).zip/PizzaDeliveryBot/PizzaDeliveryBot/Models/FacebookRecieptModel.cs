﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PizzaDeliveryBot.Models
{
    public class Messenger
    {
        public MessengerChannelData ChannelData { get; set; }

        public static object getFBFunctionMenu()
        {
            Messenger fbmsg = new Messenger();
            fbmsg.ChannelData = new MessengerChannelData { notification_type = "NO_PUSH", attachment = new MessengerAttachment { payload = new MessengerPayload() } };
            fbmsg.ChannelData.attachment.type = "template";
            fbmsg.ChannelData.attachment.payload.template_type = "generic";
            List<MessengerElement> e = new List<MessengerElement>();
            List<MessengerButton> bs = new List<MessengerButton>();
            bs.Add(new MessengerButton { type = "web_url", title = "Facebook", url = "http://www.facebook.com/" });
            bs.Add(new MessengerButton { type = "web_url", title = "Google", url = "http://www.google.com/" });
            bs.Add(new MessengerButton { type = "web_url", title = "Amazon", url = "http://www.amazon.com/" });
            e.Add(new MessengerElement
            {
                title = "My Favorte Site",
                subtitle = "some descript",
                item_url = "http://localhost/",
                image_url = "http://loalhost/img.png",
                buttons = bs.ToArray()
            });
            fbmsg.ChannelData.attachment.payload.elements = e.ToArray();
            return fbmsg.ChannelData;
        }
    }
    public class MessengerChannelData
    {
        public string notification_type { get; set; }
        public MessengerAttachment attachment { get; set; }
    }
    public class MessengerAttachment
    {
        public string type { get; set; }
        public MessengerPayload payload { get; set; }
    }

    public class MessengerPayload
    {
        public string template_type { get; set; }
        public MessengerElement[] elements { get; set; }
    }

    public class MessengerElement
    {
        public string title { get; set; }
        public string subtitle { get; set; }
        public string item_url { get; set; }
        public string image_url { get; set; }
        public MessengerButton[] buttons { get; set; }
    }

    public class MessengerButton
    {
        public string type { get; set; }
        public string url { get; set; }
        public string title { get; set; }
        public string payload { get; set; }
    }
}